const images = [ 
  './images/luke_skywalker.jpeg',
  './images/C-3PO.jpeg',
  './images/R2-D2.jpeg',
  './images/darth_vader.jpeg',
  './images/darth_vader.jpeg',
  './images/leio_organa.jpeg',
  './images/owen_lars.jpeg',
  './images/beru_lars.jpeg',
  './images/R5-D4.jpeg',
  './images/biggs_darklighter.jpeg',
  './images/obi-wan_kenobi.jpeg',
]